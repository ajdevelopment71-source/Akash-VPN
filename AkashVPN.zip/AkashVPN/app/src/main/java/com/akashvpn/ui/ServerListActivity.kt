package com.akashvpn.ui

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.SearchView
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.akashvpn.databinding.ActivityServerListBinding
import com.akashvpn.model.VpnServer

class ServerListActivity : AppCompatActivity() {

    private lateinit var binding: ActivityServerListBinding
    private val viewModel: MainViewModel by viewModels()
    private lateinit var adapter: ServerAdapter
    private var allServers: List<VpnServer> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityServerListBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "Select Server"

        setupRecyclerView()
        setupSearch()
        observeViewModel()

        if (viewModel.servers.value.isNullOrEmpty()) {
            viewModel.fetchServers()
        }
    }

    private fun setupRecyclerView() {
        adapter = ServerAdapter { server ->
            val index = allServers.indexOf(server)
            val result = Intent().apply {
                putExtra("server_ip", server.ip)
                putExtra("server_index", index)
            }
            setResult(RESULT_OK, result)
            finish()
        }
        binding.rvServers.layoutManager = LinearLayoutManager(this)
        binding.rvServers.adapter = adapter
    }

    private fun setupSearch() {
        binding.searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?) = false
            override fun onQueryTextChange(newText: String?): Boolean {
                val q = newText?.lowercase().orEmpty()
                val filtered = if (q.isEmpty()) allServers
                else allServers.filter {
                    it.countryLong.lowercase().contains(q) ||
                    it.countryShort.lowercase().contains(q)
                }
                adapter.submitList(filtered)
                return true
            }
        })
    }

    private fun observeViewModel() {
        viewModel.servers.observe(this) { servers ->
            allServers = servers
            adapter.submitList(servers)
            binding.tvEmpty.visibility = if (servers.isEmpty()) View.VISIBLE else View.GONE
        }
        viewModel.loading.observe(this) { loading ->
            binding.progressBar.visibility = if (loading) View.VISIBLE else View.GONE
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressedDispatcher.onBackPressed()
        return true
    }
}
