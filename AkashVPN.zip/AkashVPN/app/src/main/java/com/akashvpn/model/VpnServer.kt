package com.akashvpn.model

data class VpnServer(
    val hostName: String,
    val ip: String,
    val score: Long,
    val ping: Int,
    val speed: Long,
    val countryLong: String,
    val countryShort: String,
    val numSessions: Int,
    val operator: String,
    val ovpnConfigBase64: String
) {
    val flagEmoji: String get() {
        val offset = 0x1F1E6 - 'A'.code
        return if (countryShort.length == 2) {
            countryShort.uppercase().map { char ->
                String(Character.toChars(char.code + offset))
            }.joinToString("")
        } else "🌐"
    }

    val speedMbps: String get() {
        val mbps = speed / 1_000_000.0
        return if (mbps >= 1) "%.1f Mbps".format(mbps)
        else "${(speed / 1000)} Kbps"
    }

    val pingText: String get() = if (ping > 0) "${ping}ms" else "N/A"
}
