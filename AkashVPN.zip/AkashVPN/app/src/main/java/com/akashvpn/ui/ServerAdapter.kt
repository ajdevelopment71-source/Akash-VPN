package com.akashvpn.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.akashvpn.R
import com.akashvpn.model.VpnServer

class ServerAdapter(
    private val onSelect: (VpnServer) -> Unit
) : ListAdapter<VpnServer, ServerAdapter.ServerViewHolder>(DIFF) {

    private var selectedPosition = 0

    companion object {
        val DIFF = object : DiffUtil.ItemCallback<VpnServer>() {
            override fun areItemsTheSame(a: VpnServer, b: VpnServer) = a.ip == b.ip
            override fun areContentsTheSame(a: VpnServer, b: VpnServer) = a == b
        }
    }

    inner class ServerViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val card: CardView    = view.findViewById(R.id.cardServer)
        val flag: TextView    = view.findViewById(R.id.tvFlag)
        val country: TextView = view.findViewById(R.id.tvCountry)
        val speed: TextView   = view.findViewById(R.id.tvSpeed)
        val ping: TextView    = view.findViewById(R.id.tvPing)
        val sessions: TextView = view.findViewById(R.id.tvSessions)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ServerViewHolder {
        val v = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_server, parent, false)
        return ServerViewHolder(v)
    }

    override fun onBindViewHolder(holder: ServerViewHolder, position: Int) {
        val server = getItem(position)
        holder.flag.text    = server.flagEmoji
        holder.country.text = server.countryLong
        holder.speed.text   = "⚡ ${server.speedMbps}"
        holder.ping.text    = "📡 ${server.pingText}"
        holder.sessions.text = "👥 ${server.numSessions}"

        val isSelected = position == selectedPosition
        val ctx = holder.itemView.context
        holder.card.setCardBackgroundColor(
            if (isSelected) ctx.getColor(R.color.selected_card)
            else ctx.getColor(R.color.card_background)
        )
        holder.card.cardElevation = if (isSelected) 12f else 4f

        holder.card.setOnClickListener {
            val prev = selectedPosition
            selectedPosition = holder.bindingAdapterPosition
            notifyItemChanged(prev)
            notifyItemChanged(selectedPosition)
            onSelect(server)
        }
    }

    fun setSelectedIndex(index: Int) {
        val prev = selectedPosition
        selectedPosition = index
        notifyItemChanged(prev)
        notifyItemChanged(selectedPosition)
    }
}
