package com.akashvpn.ui

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.VpnService
import android.os.Bundle
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.akashvpn.R
import com.akashvpn.databinding.ActivityMainBinding
import com.akashvpn.model.VpnServer
import com.akashvpn.vpn.AkashVpnService

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val viewModel: MainViewModel by viewModels()
    private var pulseAnimator: ValueAnimator? = null
    private var isConnected = false

    private val vpnLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            doConnect()
        }
    }

    private val vpnReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val connected = intent?.getBooleanExtra("connected", false) ?: false
            setConnectionState(connected)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupUI()
        observeViewModel()
        viewModel.fetchServers()

        registerReceiver(
            vpnReceiver,
            IntentFilter("com.akashvpn.VPN_STATE_CHANGED"),
            Context.RECEIVER_NOT_EXPORTED
        )
    }

    private fun setupUI() {
        binding.btnConnect.setOnClickListener {
            if (isConnected) disconnectVpn() else connectVpn()
        }

        binding.btnRefresh.setOnClickListener {
            viewModel.fetchServers()
        }

        binding.cardServer.setOnClickListener {
            val servers = viewModel.servers.value
            if (!servers.isNullOrEmpty()) {
                val intent = Intent(this, ServerListActivity::class.java)
                startActivityForResult(intent, 100)
            } else {
                Toast.makeText(this, "Fetching servers...", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun observeViewModel() {
        viewModel.loading.observe(this) { loading ->
            binding.progressBar.visibility = if (loading) View.VISIBLE else View.GONE
            binding.tvLoadingText.visibility = if (loading) View.VISIBLE else View.GONE
        }

        viewModel.selectedServer.observe(this) { server ->
            server?.let { updateServerCard(it) }
        }

        viewModel.error.observe(this) { error ->
            error?.let { Toast.makeText(this, it, Toast.LENGTH_LONG).show() }
        }
    }

    private fun updateServerCard(server: VpnServer) {
        binding.tvServerFlag.text    = server.flagEmoji
        binding.tvServerCountry.text = server.countryLong
        binding.tvServerSpeed.text   = "⚡ ${server.speedMbps}"
        binding.tvServerPing.text    = "📡 ${server.pingText}"
    }

    private fun connectVpn() {
        val intent = VpnService.prepare(this)
        if (intent != null) {
            vpnLauncher.launch(intent)
        } else {
            doConnect()
        }
    }

    private fun doConnect() {
        val server = viewModel.selectedServer.value
        if (server == null) {
            Toast.makeText(this, "Please select a server first", Toast.LENGTH_SHORT).show()
            return
        }
        setButtonConnecting()
        val intent = Intent(this, AkashVpnService::class.java).apply {
            action = AkashVpnService.ACTION_CONNECT
            putExtra(AkashVpnService.EXTRA_SERVER_IP, server.ip)
        }
        startService(intent)
        // Simulate connection delay
        binding.root.postDelayed({ setConnectionState(true) }, 2000)
    }

    private fun disconnectVpn() {
        val intent = Intent(this, AkashVpnService::class.java).apply {
            action = AkashVpnService.ACTION_DISCONNECT
        }
        startService(intent)
        setConnectionState(false)
    }

    private fun setButtonConnecting() {
        binding.btnConnect.isEnabled = false
        binding.tvStatus.text = "Connecting..."
        binding.tvStatus.setTextColor(getColor(R.color.connecting_color))
        startPulseAnimation()
    }

    private fun setConnectionState(connected: Boolean) {
        isConnected = connected
        binding.btnConnect.isEnabled = true

        if (connected) {
            binding.btnConnect.text = "DISCONNECT"
            binding.btnConnect.backgroundTintList =
                ContextCompat.getColorStateList(this, R.color.btn_disconnect)
            binding.tvStatus.text = "● Connected"
            binding.tvStatus.setTextColor(getColor(R.color.connected_color))
            binding.ringOuter.setColorFilter(getColor(R.color.connected_color))
            startPulseAnimation()
        } else {
            stopPulseAnimation()
            binding.btnConnect.text = "CONNECT"
            binding.btnConnect.backgroundTintList =
                ContextCompat.getColorStateList(this, R.color.btn_connect)
            binding.tvStatus.text = "● Disconnected"
            binding.tvStatus.setTextColor(getColor(R.color.disconnected_color))
            binding.ringOuter.setColorFilter(getColor(R.color.primary))
        }
    }

    private fun startPulseAnimation() {
        pulseAnimator?.cancel()
        pulseAnimator = ValueAnimator.ofFloat(0.9f, 1.1f).apply {
            duration = 1000
            repeatMode = ValueAnimator.REVERSE
            repeatCount = ValueAnimator.INFINITE
            interpolator = AccelerateDecelerateInterpolator()
            addUpdateListener { anim ->
                val scale = anim.animatedValue as Float
                binding.ringOuter.scaleX = scale
                binding.ringOuter.scaleY = scale
            }
            start()
        }
    }

    private fun stopPulseAnimation() {
        pulseAnimator?.cancel()
        pulseAnimator = null
        binding.ringOuter.scaleX = 1f
        binding.ringOuter.scaleY = 1f
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 100 && resultCode == RESULT_OK) {
            val ip   = data?.getStringExtra("server_ip") ?: return
            val idx  = data.getIntExtra("server_index", 0)
            val servers = viewModel.servers.value ?: return
            val server = servers.getOrNull(idx) ?: return
            viewModel.selectServer(server)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        unregisterReceiver(vpnReceiver)
        pulseAnimator?.cancel()
    }
}
