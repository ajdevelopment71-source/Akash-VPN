package com.akashvpn.vpn

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import androidx.core.app.NotificationCompat
import com.akashvpn.R
import com.akashvpn.ui.MainActivity
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.nio.ByteBuffer

class AkashVpnService : VpnService() {

    companion object {
        const val ACTION_CONNECT    = "com.akashvpn.CONNECT"
        const val ACTION_DISCONNECT = "com.akashvpn.DISCONNECT"
        const val EXTRA_SERVER_IP   = "server_ip"
        const val CHANNEL_ID        = "akash_vpn_channel"

        var isRunning = false
        var currentServer = ""
    }

    private var vpnInterface: ParcelFileDescriptor? = null
    private var running = false

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return when (intent?.action) {
            ACTION_CONNECT -> {
                val serverIp = intent.getStringExtra(EXTRA_SERVER_IP) ?: ""
                startForeground(1, buildNotification("Connecting..."))
                connect(serverIp)
                START_STICKY
            }
            ACTION_DISCONNECT -> {
                disconnect()
                stopForeground(true)
                stopSelf()
                START_NOT_STICKY
            }
            else -> START_NOT_STICKY
        }
    }

    private fun connect(serverIp: String) {
        try {
            currentServer = serverIp
            vpnInterface = Builder()
                .setSession("Akash VPN")
                .addAddress("10.8.0.2", 24)
                .addDnsServer("8.8.8.8")
                .addDnsServer("8.8.4.4")
                .addRoute("0.0.0.0", 0)
                .setMtu(1500)
                .establish()

            isRunning = true
            running = true
            startForeground(1, buildNotification("Connected to $serverIp"))
            sendBroadcast(Intent("com.akashvpn.VPN_STATE_CHANGED").apply {
                putExtra("connected", true)
            })
        } catch (e: Exception) {
            disconnect()
        }
    }

    private fun disconnect() {
        running = false
        isRunning = false
        currentServer = ""
        try {
            vpnInterface?.close()
            vpnInterface = null
        } catch (_: Exception) {}
        sendBroadcast(Intent("com.akashvpn.VPN_STATE_CHANGED").apply {
            putExtra("connected", false)
        })
    }

    private fun buildNotification(text: String): Notification {
        createChannel()
        val pendingIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Akash VPN")
            .setContentText(text)
            .setSmallIcon(R.drawable.ic_vpn_key)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .build()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, "Akash VPN", NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java)?.createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        disconnect()
        super.onDestroy()
    }
}
