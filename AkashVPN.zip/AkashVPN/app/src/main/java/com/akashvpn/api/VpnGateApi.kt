package com.akashvpn.api

import com.akashvpn.model.VpnServer
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

object VpnGateApi {

    private const val API_URL = "https://www.vpngate.net/api/iphone/"
    private const val FALLBACK_URL = "http://www.vpngate.net/api/iphone/"

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build()

    fun fetchServers(): List<VpnServer> {
        val csv = fetchCsv(API_URL) ?: fetchCsv(FALLBACK_URL) ?: return emptyList()
        return parseCsv(csv)
    }

    private fun fetchCsv(url: String): String? {
        return try {
            val request = Request.Builder().url(url).build()
            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) response.body?.string() else null
            }
        } catch (e: Exception) { null }
    }

    private fun parseCsv(csv: String): List<VpnServer> {
        val lines = csv.lines()
        // Find header line
        val headerIndex = lines.indexOfFirst {
            it.startsWith("#") && it.contains("HostName")
        }
        if (headerIndex < 0) return emptyList()

        return lines.drop(headerIndex + 1)
            .filter { it.isNotBlank() && !it.startsWith("*") }
            .mapNotNull { line -> parseLine(line) }
            .sortedByDescending { it.speed }
            .take(50)
    }

    private fun parseLine(line: String): VpnServer? {
        return try {
            val cols = line.split(",")
            if (cols.size < 15) return null
            VpnServer(
                hostName     = cols[0].trim(),
                ip           = cols[1].trim(),
                score        = cols[2].trim().toLongOrNull() ?: 0L,
                ping         = cols[3].trim().toIntOrNull() ?: 0,
                speed        = cols[4].trim().toLongOrNull() ?: 0L,
                countryLong  = cols[5].trim(),
                countryShort = cols[6].trim(),
                numSessions  = cols[7].trim().toIntOrNull() ?: 0,
                operator     = cols[12].trim(),
                ovpnConfigBase64 = cols[14].trim()
            )
        } catch (e: Exception) { null }
    }
}
