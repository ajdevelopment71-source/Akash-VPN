package com.akashvpn.ui

import android.animation.ValueAnimator
import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.PorterDuff
import android.net.VpnService
import android.os.Bundle
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.akashvpn.R
import com.akashvpn.databinding.ActivityMainBinding
import com.akashvpn.vpn.AkashVpnService

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private val viewModel: MainViewModel by viewModels()
    private var pulseAnimator: ValueAnimator? = null
    private var isConnected = false

    private val vpnLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        if (it.resultCode == Activity.RESULT_OK) doConnect()
    }

    private val vpnReceiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context?, intent: Intent?) {
            setConnectionState(intent?.getBooleanExtra("connected", false) ?: false)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.ringOuter.setColorFilter(ContextCompat.getColor(this, R.color.primary), PorterDuff.Mode.SRC_IN)
        binding.btnConnect.setOnClickListener { if (isConnected) disconnectVpn() else connectVpn() }
        binding.btnRefresh.setOnClickListener { viewModel.fetchServers() }
        binding.cardServer.setOnClickListener {
            if (!viewModel.servers.value.isNullOrEmpty())
                startActivityForResult(Intent(this, ServerListActivity::class.java), 100)
            else Toast.makeText(this, "Fetching servers...", Toast.LENGTH_SHORT).show()
        }
        viewModel.loading.observe(this) {
            binding.progressBar.visibility = if (it) View.VISIBLE else View.GONE
            binding.tvLoadingText.visibility = if (it) View.VISIBLE else View.GONE
        }
        viewModel.selectedServer.observe(this) { s ->
            s?.let {
                binding.tvServerFlag.text = it.flagEmoji
                binding.tvServerCountry.text = it.countryLong
                binding.tvServerSpeed.text = "⚡ ${it.speedMbps}"
                binding.tvServerPing.text = "📡 ${it.pingText}"
            }
        }
        viewModel.error.observe(this) { it?.let { msg -> Toast.makeText(this, msg, Toast.LENGTH_LONG).show() } }
        viewModel.fetchServers()
        registerReceiver(vpnReceiver, IntentFilter("com.akashvpn.VPN_STATE_CHANGED"))
    }

    private fun connectVpn() {
        val intent = VpnService.prepare(this)
        if (intent != null) vpnLauncher.launch(intent) else doConnect()
    }

    private fun doConnect() {
        val server = viewModel.selectedServer.value ?: run {
            Toast.makeText(this, "Select a server first", Toast.LENGTH_SHORT).show(); return
        }
        binding.tvStatus.text = "Connecting..."; binding.tvStatus.setTextColor(getColor(R.color.connecting_color))
        startPulseAnimation()
        startService(Intent(this, AkashVpnService::class.java).apply {
            action = AkashVpnService.ACTION_CONNECT
            putExtra(AkashVpnService.EXTRA_SERVER_IP, server.ip)
        })
        binding.root.postDelayed({ setConnectionState(true) }, 2000)
    }

    private fun disconnectVpn() {
        startService(Intent(this, AkashVpnService::class.java).apply { action = AkashVpnService.ACTION_DISCONNECT })
        setConnectionState(false)
    }

    private fun setConnectionState(connected: Boolean) {
        isConnected = connected
        if (connected) {
            binding.btnConnect.text = "DISCONNECT"
            binding.btnConnect.backgroundTintList = ContextCompat.getColorStateList(this, R.color.btn_disconnect)
            binding.tvStatus.text = "● Connected"; binding.tvStatus.setTextColor(getColor(R.color.connected_color))
            binding.ringOuter.setColorFilter(ContextCompat.getColor(this, R.color.connected_color), PorterDuff.Mode.SRC_IN)
            startPulseAnimation()
        } else {
            stopPulseAnimation()
            binding.btnConnect.text = "CONNECT"
            binding.btnConnect.backgroundTintList = ContextCompat.getColorStateList(this, R.color.btn_connect)
            binding.tvStatus.text = "● Disconnected"; binding.tvStatus.setTextColor(getColor(R.color.disconnected_color))
            binding.ringOuter.setColorFilter(ContextCompat.getColor(this, R.color.primary), PorterDuff.Mode.SRC_IN)
        }
    }

    private fun startPulseAnimation() {
        pulseAnimator?.cancel()
        pulseAnimator = ValueAnimator.ofFloat(0.92f, 1.08f).apply {
            duration = 1000; repeatMode = ValueAnimator.REVERSE; repeatCount = ValueAnimator.INFINITE
            interpolator = AccelerateDecelerateInterpolator()
            addUpdateListener { v ->
                val s = v.animatedValue as Float
                binding.ringOuter.scaleX = s; binding.ringOuter.scaleY = s
            }
            start()
        }
    }

    private fun stopPulseAnimation() {
        pulseAnimator?.cancel(); binding.ringOuter.scaleX = 1f; binding.ringOuter.scaleY = 1f
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 100 && resultCode == RESULT_OK) {
            val idx = data?.getIntExtra("server_index", 0) ?: return
            viewModel.servers.value?.getOrNull(idx)?.let { viewModel.selectServer(it) }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        try { unregisterReceiver(vpnReceiver) } catch (_: Exception) {}
        pulseAnimator?.cancel()
    }
}
