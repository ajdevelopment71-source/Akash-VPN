package com.akashvpn.ui

import androidx.lifecycle.*
import com.akashvpn.api.VpnGateApi
import com.akashvpn.model.VpnServer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class MainViewModel : ViewModel() {
    private val _servers = MutableLiveData<List<VpnServer>>(emptyList())
    val servers: LiveData<List<VpnServer>> = _servers
    private val _loading = MutableLiveData(false)
    val loading: LiveData<Boolean> = _loading
    private val _error = MutableLiveData<String?>(null)
    val error: LiveData<String?> = _error
    private val _selectedServer = MutableLiveData<VpnServer?>(null)
    val selectedServer: LiveData<VpnServer?> = _selectedServer

    fun fetchServers() {
        _loading.value = true; _error.value = null
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val list = VpnGateApi.fetchServers()
                _servers.postValue(list)
                if (list.isNotEmpty() && _selectedServer.value == null) _selectedServer.postValue(list.first())
            } catch (e: Exception) { _error.postValue("Failed to fetch servers.") }
            finally { _loading.postValue(false) }
        }
    }
    fun selectServer(s: VpnServer) { _selectedServer.value = s }
}
