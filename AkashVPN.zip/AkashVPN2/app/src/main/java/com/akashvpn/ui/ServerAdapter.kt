package com.akashvpn.ui

import android.view.*
import android.widget.TextView
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.*
import com.akashvpn.R
import com.akashvpn.model.VpnServer

class ServerAdapter(private val onSelect: (VpnServer, Int) -> Unit) :
    ListAdapter<VpnServer, ServerAdapter.VH>(object : DiffUtil.ItemCallback<VpnServer>() {
        override fun areItemsTheSame(a: VpnServer, b: VpnServer) = a.ip == b.ip
        override fun areContentsTheSame(a: VpnServer, b: VpnServer) = a == b
    }) {
    private var selectedPos = 0

    inner class VH(v: View) : RecyclerView.ViewHolder(v) {
        val card: CardView = v.findViewById(R.id.cardServer)
        val flag: TextView = v.findViewById(R.id.tvFlag)
        val country: TextView = v.findViewById(R.id.tvCountry)
        val speed: TextView = v.findViewById(R.id.tvSpeed)
        val ping: TextView = v.findViewById(R.id.tvPing)
        val sessions: TextView = v.findViewById(R.id.tvSessions)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_server, parent, false))

    override fun onBindViewHolder(h: VH, pos: Int) {
        val s = getItem(pos)
        h.flag.text = s.flagEmoji; h.country.text = s.countryLong
        h.speed.text = "⚡ ${s.speedMbps}"; h.ping.text = "📡 ${s.pingText}"
        h.sessions.text = "👥 ${s.numSessions}"
        val ctx = h.itemView.context
        h.card.setCardBackgroundColor(
            if (pos == selectedPos) ctx.getColor(R.color.selected_card)
            else ctx.getColor(R.color.card_background))
        h.card.cardElevation = if (pos == selectedPos) 12f else 4f
        h.card.setOnClickListener {
            val prev = selectedPos; selectedPos = h.bindingAdapterPosition
            notifyItemChanged(prev); notifyItemChanged(selectedPos)
            onSelect(s, selectedPos)
        }
    }
}
