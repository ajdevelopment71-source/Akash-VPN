package com.akashvpn.vpn

import android.app.*
import android.content.Intent
import android.net.VpnService
import android.os.Build
import androidx.core.app.NotificationCompat
import com.akashvpn.R
import com.akashvpn.ui.MainActivity

class AkashVpnService : VpnService() {
    companion object {
        const val ACTION_CONNECT = "com.akashvpn.CONNECT"
        const val ACTION_DISCONNECT = "com.akashvpn.DISCONNECT"
        const val EXTRA_SERVER_IP = "server_ip"
        const val CHANNEL_ID = "akash_vpn"
        var isRunning = false
    }

    private var vpnInterface: android.os.ParcelFileDescriptor? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return when (intent?.action) {
            ACTION_CONNECT -> {
                val ip = intent.getStringExtra(EXTRA_SERVER_IP) ?: ""
                createChannel()
                startForeground(1, buildNotification("Connected to $ip"))
                connect(ip); START_STICKY
            }
            ACTION_DISCONNECT -> { disconnect(); stopForeground(true); stopSelf(); START_NOT_STICKY }
            else -> START_NOT_STICKY
        }
    }

    private fun connect(ip: String) {
        try {
            vpnInterface = Builder().setSession("Akash VPN")
                .addAddress("10.8.0.2", 24).addDnsServer("8.8.8.8")
                .addRoute("0.0.0.0", 0).setMtu(1500).establish()
            isRunning = true
            sendBroadcast(Intent("com.akashvpn.VPN_STATE_CHANGED").putExtra("connected", true))
        } catch (e: Exception) { disconnect() }
    }

    private fun disconnect() {
        isRunning = false
        try { vpnInterface?.close(); vpnInterface = null } catch (_: Exception) {}
        sendBroadcast(Intent("com.akashvpn.VPN_STATE_CHANGED").putExtra("connected", false))
    }

    private fun buildNotification(text: String): Notification {
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Akash VPN").setContentText(text)
            .setSmallIcon(R.drawable.ic_vpn_key).setContentIntent(pi).setOngoing(true).build()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            getSystemService(NotificationManager::class.java)
                ?.createNotificationChannel(NotificationChannel(CHANNEL_ID, "Akash VPN", NotificationManager.IMPORTANCE_LOW))
        }
    }

    override fun onDestroy() { disconnect(); super.onDestroy() }
}
