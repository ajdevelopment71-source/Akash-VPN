package com.akashvpn.ui

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.SearchView
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.akashvpn.databinding.ActivityServerListBinding
import com.akashvpn.model.VpnServer

class ServerListActivity : AppCompatActivity() {
    private lateinit var binding: ActivityServerListBinding
    private val viewModel: MainViewModel by viewModels()
    private lateinit var adapter: ServerAdapter
    private var allServers: List<VpnServer> = emptyList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityServerListBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "Select Server"

        adapter = ServerAdapter { server, idx ->
            setResult(RESULT_OK, Intent().putExtra("server_index", idx))
            viewModel.selectServer(server)
            finish()
        }
        binding.rvServers.layoutManager = LinearLayoutManager(this)
        binding.rvServers.adapter = adapter

        binding.searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(q: String?) = false
            override fun onQueryTextChange(q: String?): Boolean {
                val filtered = if (q.isNullOrBlank()) allServers
                else allServers.filter { it.countryLong.lowercase().contains(q.lowercase()) }
                adapter.submitList(filtered); return true
            }
        })

        viewModel.servers.observe(this) { list ->
            allServers = list; adapter.submitList(list)
            binding.tvEmpty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
        }
        viewModel.loading.observe(this) { binding.progressBar.visibility = if (it) View.VISIBLE else View.GONE }
        if (viewModel.servers.value.isNullOrEmpty()) viewModel.fetchServers()
    }

    override fun onSupportNavigateUp(): Boolean { onBackPressedDispatcher.onBackPressed(); return true }
}
