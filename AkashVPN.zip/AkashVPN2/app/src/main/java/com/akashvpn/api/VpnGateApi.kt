package com.akashvpn.api

import com.akashvpn.model.VpnServer
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

object VpnGateApi {
    private const val URL = "https://www.vpngate.net/api/iphone/"
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS).readTimeout(20, TimeUnit.SECONDS).build()

    fun fetchServers(): List<VpnServer> {
        return try {
            val csv = client.newCall(Request.Builder().url(URL).build())
                .execute().use { it.body?.string() } ?: return emptyList()
            parseCsv(csv)
        } catch (e: Exception) { emptyList() }
    }

    private fun parseCsv(csv: String): List<VpnServer> {
        val lines = csv.lines()
        val hi = lines.indexOfFirst { it.startsWith("#") && it.contains("HostName") }
        if (hi < 0) return emptyList()
        return lines.drop(hi + 1).filter { it.isNotBlank() && !it.startsWith("*") }
            .mapNotNull { parseLine(it) }.sortedByDescending { it.speed }.take(50)
    }

    private fun parseLine(line: String): VpnServer? = try {
        val c = line.split(",")
        if (c.size < 15) null
        else VpnServer(c[0].trim(), c[1].trim(), c[2].trim().toLongOrNull() ?: 0,
            c[3].trim().toIntOrNull() ?: 0, c[4].trim().toLongOrNull() ?: 0,
            c[5].trim(), c[6].trim(), c[7].trim().toIntOrNull() ?: 0, c[12].trim(), c[14].trim())
    } catch (e: Exception) { null }
}
