package com.akash.vpn.service

import android.content.Context
import android.content.Intent
import android.net.VpnService
import de.blinkt.openvpn.VpnProfile
import de.blinkt.openvpn.core.ConfigParser
import de.blinkt.openvpn.core.ProfileManager
import de.blinkt.openvpn.core.VPNLaunchHelper
import com.akash.vpn.model.VpnServer
import java.io.InputStreamReader

object VpnConnectionManager {

    private var currentProfile: VpnProfile? = null

    fun prepareAndConnect(context: Context, server: VpnServer): Intent? {
        // Check if VPN permission is needed
        val intent = VpnService.prepare(context)
        if (intent != null) return intent  // Caller must startActivityForResult

        startVpn(context, server)
        return null
    }

    fun startVpn(context: Context, server: VpnServer) {
        try {
            val assetStream = context.assets.open(server.ovpnAsset)
            val reader = InputStreamReader(assetStream)

            val parser = ConfigParser()
            parser.parseConfig(reader)

            val profile = parser.convertProfile()
            profile.mName = server.name
            profile.mUsername = "vpn"
            profile.mPassword = "vpn"

            ProfileManager.getInstance(context).addProfile(profile)
            ProfileManager.getInstance(context).saveProfile(context, profile)
            ProfileManager.getInstance(context).saveProfileList(context)

            currentProfile = profile

            VPNLaunchHelper.startOpenVpn(profile, context)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun stopVpn(context: Context) {
        val stopIntent = Intent(context,
            de.blinkt.openvpn.core.OpenVPNService::class.java)
        stopIntent.action = de.blinkt.openvpn.core.OpenVPNService.DISCONNECT_VPN
        context.startService(stopIntent)
    }
}
