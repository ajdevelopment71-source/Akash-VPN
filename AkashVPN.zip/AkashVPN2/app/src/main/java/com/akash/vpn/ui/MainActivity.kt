package com.akash.vpn.ui

import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import com.akash.vpn.R
import com.akash.vpn.databinding.ActivityMainBinding
import com.akash.vpn.model.VpnServer
import com.akash.vpn.service.VpnConnectionManager
import com.akash.vpn.util.ServerRepository
import de.blinkt.openvpn.core.VpnStatus

class MainActivity : AppCompatActivity(), VpnStatus.StateListener {

    private lateinit var binding: ActivityMainBinding
    private lateinit var adapter: ServerAdapter
    private var selectedServer: VpnServer? = null
    private var isConnected = false

    companion object {
        private const val VPN_REQUEST_CODE = 100
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupRecyclerView()
        setupConnectButton()
        VpnStatus.addStateListener(this)
        updateUI(false)
    }

    private fun setupRecyclerView() {
        adapter = ServerAdapter(ServerRepository.servers) { server ->
            selectedServer = server
            binding.tvSelectedServer.text = "${server.flag} ${server.name}"
        }
        binding.rvServers.layoutManager = LinearLayoutManager(this)
        binding.rvServers.adapter = adapter

        // Auto-select first
        selectedServer = ServerRepository.servers.first()
        adapter.setSelected(selectedServer!!.id)
        binding.tvSelectedServer.text = "${selectedServer!!.flag} ${selectedServer!!.name}"
    }

    private fun setupConnectButton() {
        binding.btnConnect.setOnClickListener {
            if (isConnected) {
                VpnConnectionManager.stopVpn(this)
            } else {
                val server = selectedServer ?: run {
                    Toast.makeText(this, "Please select a server", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                val intent = VpnConnectionManager.prepareAndConnect(this, server)
                if (intent != null) {
                    startActivityForResult(intent, VPN_REQUEST_CODE)
                }
            }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == VPN_REQUEST_CODE && resultCode == Activity.RESULT_OK) {
            selectedServer?.let { VpnConnectionManager.startVpn(this, it) }
        }
    }

    override fun updateState(
        state: String?,
        logmessage: String?,
        localizedResId: Int,
        level: VpnStatus.ConnectionStatus?,
        Intent?
    ) {
        runOnUiThread {
            when (level) {
                VpnStatus.ConnectionStatus.LEVEL_CONNECTED -> {
                    isConnected = true
                    updateUI(true)
                    binding.tvStatus.text = "✅ Connected"
                }
                VpnStatus.ConnectionStatus.LEVEL_CONNECTING_SERVER_REPLIED,
                VpnStatus.ConnectionStatus.LEVEL_CONNECTING_NO_SERVER_REPLY_YET -> {
                    binding.tvStatus.text = "⏳ Connecting..."
                }
                VpnStatus.ConnectionStatus.LEVEL_NOTCONNECTED -> {
                    isConnected = false
                    updateUI(false)
                    binding.tvStatus.text = "🔴 Disconnected"
                }
                else -> {
                    binding.tvStatus.text = state ?: "Unknown"
                }
            }
        }
    }

    override fun setConnectedVPN(uuid: String?) {}

    private fun updateUI(connected: Boolean) {
        if (connected) {
            binding.btnConnect.text = "DISCONNECT"
            binding.btnConnect.setBackgroundColor(
                ContextCompat.getColor(this, R.color.disconnect_red)
            )
            binding.ivShield.setImageResource(R.drawable.ic_shield_on)
        } else {
            binding.btnConnect.text = "CONNECT"
            binding.btnConnect.setBackgroundColor(
                ContextCompat.getColor(this, R.color.connect_green)
            )
            binding.ivShield.setImageResource(R.drawable.ic_shield_off)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        VpnStatus.removeStateListener(this)
    }
}
