package com.akash.vpn.model

data class VpnServer(
    val id: String,
    val name: String,
    val country: String,
    val flag: String,
    val ovpnAsset: String,
    val protocol: String,
    val ping: String = "—"
)
