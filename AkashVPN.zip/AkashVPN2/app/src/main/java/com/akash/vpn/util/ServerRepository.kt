package com.akash.vpn.util

import com.akash.vpn.model.VpnServer

object ServerRepository {
    val servers = listOf(
        VpnServer(
            id = "japan",
            name = "Japan",
            country = "Japan",
            flag = "🇯🇵",
            ovpnAsset = "vpn/japan.ovpn",
            protocol = "TCP 443"
        ),
        VpnServer(
            id = "korea",
            name = "Korea",
            country = "South Korea",
            flag = "🇰🇷",
            ovpnAsset = "vpn/korea.ovpn",
            protocol = "TCP 1804"
        ),
        VpnServer(
            id = "thailand",
            name = "Thailand",
            country = "Thailand",
            flag = "🇹🇭",
            ovpnAsset = "vpn/thailand.ovpn",
            protocol = "UDP 1245"
        )
    )
}
