package com.akash.vpn.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.akash.vpn.R
import com.akash.vpn.model.VpnServer

class ServerAdapter(
    private val servers: List<VpnServer>,
    private val onClick: (VpnServer) -> Unit
) : RecyclerView.Adapter<ServerAdapter.ViewHolder>() {

    private var selectedId: String? = null

    inner class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvFlag: TextView = view.findViewById(R.id.tvFlag)
        val tvName: TextView = view.findViewById(R.id.tvName)
        val tvProtocol: TextView = view.findViewById(R.id.tvProtocol)
        val tvPing: TextView = view.findViewById(R.id.tvPing)
        val cardRoot: View = view.findViewById(R.id.cardRoot)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_server, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val server = servers[position]
        holder.tvFlag.text = server.flag
        holder.tvName.text = server.name
        holder.tvProtocol.text = server.protocol
        holder.tvPing.text = server.ping

        val isSelected = server.id == selectedId
        holder.cardRoot.isSelected = isSelected
        holder.cardRoot.setBackgroundResource(
            if (isSelected) R.drawable.bg_server_selected else R.drawable.bg_server_normal
        )

        holder.itemView.setOnClickListener {
            val prev = servers.indexOfFirst { it.id == selectedId }
            selectedId = server.id
            if (prev >= 0) notifyItemChanged(prev)
            notifyItemChanged(position)
            onClick(server)
        }
    }

    override fun getItemCount() = servers.size

    fun setSelected(id: String?) {
        selectedId = id
        notifyDataSetChanged()
    }
}
